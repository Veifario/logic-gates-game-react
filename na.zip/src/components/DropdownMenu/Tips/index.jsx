import TipsForAndGate from "./TipsForAndGate";
import TipsForNandGate from "./TipsForNandGate";
import TipsForNorGate from "./TipsForNorGate";
import TipsForNotGate from "./TipsForNotGate";
import TipsForOrGate from "./TipsForOrGate";

export {
	TipsForAndGate,
	TipsForNandGate,
	TipsForNorGate,
	TipsForNotGate,
	TipsForOrGate,
};
