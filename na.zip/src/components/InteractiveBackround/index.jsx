import React from "react";
import s from "./index.module.scss";
import { useState } from "react";
import Monitor from "./Monitor";
import LampAndArrow from "./LampAndArrow";

const InteractiveBackround = () => {
  
  return (
    <div className={s.root}>
      <Monitor />
      <LampAndArrow />
    </div>
  );
};

export default InteractiveBackround;
