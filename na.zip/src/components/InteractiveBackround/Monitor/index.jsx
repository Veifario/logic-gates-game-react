import React from "react";
import s from "./index.module.scss";
import img from "../../../assets/logo/png/nobaclogo.png";
import { useState } from "react";

const Monitor = () => {
  const [back, setBack] = useState("");
  return (
    <div className={s.root}>
      <div className={s.monitor}>
        <div className={s.inner}>
          <div className={s.body} style={{ backgroundColor: back }}>
            <div className={s.info}>
              привет! давайте мы расскажем немного об этой игре. <br />
              Наша игра представляет собой симулятор, который будет полезен
              любителям программирования и тем, кто только начинает свой путь в
              этой среде. Вам предстоит изучить непростую науку и внедрить ее в
              жизнь, чтобы обеспечить благополучное существование своему герою.
              Нажимай на кнопку "Играть", и приступай покорять мир кодинга,
              удачи)
            </div>
            <div onClick={() => setBack("white")} className={s.pwron}></div>
            <div onClick={() => setBack("black")} className={s.pwroff}></div>
          </div>
          <div className={s.holder1}></div>
          <div className={s.holder2}></div>
        </div>
      </div>
    </div>
  );
};

export default Monitor;
