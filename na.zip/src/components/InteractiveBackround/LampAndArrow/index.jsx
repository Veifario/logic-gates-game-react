import React from "react";
import { useState } from "react";
import s from "./index.module.scss";

const LampAndArrow = () => {
  const [lampColor, setLampColor] = useState("transparent");
  const [lampShadow, setLampShadow] = useState("none");

  const colorChanger = () => {
    if (lampColor === "transparent") {
      setLampColor("yellow");
    } else setLampColor("transparent");
  };

  const shadowChanger = () => {
    if (lampShadow === "none") {
      setLampShadow("0 0 10px 2px rgba(255,255,0,.7)");
    } else setLampShadow("none");
  };
  return (
    <div className={s.root}>
      <div
        onClick={() => {
          colorChanger();
          shadowChanger();
        }}
        className={s.switcher}
      ></div>
      <div className={s.line1}></div>
      <div className={s.line2}></div>
      <div className={s.line3}></div>
      <div className={s.line4}></div>
      <div
        className={s.lamp}
        style={{ backgroundColor: lampColor, boxShadow: lampShadow }}
      ></div>
    </div>
  );
};

export default LampAndArrow;
