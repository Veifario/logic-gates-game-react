import AndGate from "./AndGate";
import NandGate from "./NandGate";
import NorGate from "./NorGate";
import NotGate from "./NotGate";
import OrGate from "./OrGate";

export { AndGate, NandGate, NorGate, NotGate, OrGate };
