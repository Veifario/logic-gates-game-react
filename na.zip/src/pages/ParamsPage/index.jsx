import React from "react";
import s from "./index.module.scss";

const ParamsPage = () => {
  return (
    <div className={s.root}>
      <div className={s.bac}></div>
    </div>
  );
};

export default ParamsPage;
