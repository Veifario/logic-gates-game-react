import React from "react";
import s from "./index.module.scss";

const ContinuePage = () => {
	return (
		<div className={s.root}>
			<div className={s.bac}></div>
		</div>
	);
};

export default ContinuePage;
